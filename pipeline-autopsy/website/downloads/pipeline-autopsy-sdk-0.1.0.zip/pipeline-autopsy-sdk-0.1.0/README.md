# Pipeline Autopsy SDK

The Python connector for sending enterprise AI pipeline execution context to a Pipeline Autopsy collector.

## Install

```bash
pip install -e .
```

## Connect and trace

```python
import pipeline_autopsy as autopsy

autopsy.attach(
    api_key="your-api-key",
    pipeline="your-pipeline",
    collector_url="http://localhost:8000",
)

@autopsy.trace_step("extraction")
def extract(data: dict) -> dict:
    return data

with autopsy.execution(claim_id="CLM-2841"):
    result = extract({"status": "ready"})
```

The connector is best effort: if the collector is unavailable, the pipeline keeps running and the SDK logs the delivery gap.
